<?php
// @copilot migrate this file from Joomla 3 to Joomla 4 syntax
// Retain full business logic, refactor deprecated APIs, apply DI pattern

namespace Joomla\Component\Rssfactory\Administrator\Helper\Html;

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Layout\FileLayout;
use Joomla\CMS\Pagination\Pagination;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Uri\Uri;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Version;
use Joomla\CMS\Language\Text;

class RssFactoryFeedsHtml
{
    protected static $assetsLoaded = false;

    public static function display($feeds, $config = [], $ads = null)
    {
        if (!$feeds) {
            return Text::_('COM_RSSFACTORY_FEEDS_NO_FEEDS_FOUND');
        }

        $config = self::getConfig($config);
        $html = [];

        switch ($config['mode']) {
            case 'tiled':
                $html[] = self::displayTiled($feeds, $config, $ads);
                break;
            case 'tabbed':
                $html[] = self::displayTabbed($feeds, $config, $ads);
                break;
            case 'slider':
                $html[] = self::displaySliders($feeds, $config, $ads);
                break;
            case 'list':
                $html[] = self::displayList($feeds, $config, $ads);
                break;
        }

        return implode("\n", $html);
    }

    public static function displayStories($stories, $pagination = null, $config = [], $ads = null)
    {
        if (!$stories) {
            return Text::_('COM_RSSFACTORY_FEED_NO_STORIES_FOUND');
        }

        $config = self::getConfig($config);

        self::loadAssets();

        $html = [];

        $html[] = '<div class="feed-stories">';
        $html[] = '<ul class="stories ' . ($config['voting'] ? 'voting' : '') . '">';

        foreach (array_values($stories) as $i => $story) {
            $html[] = self::displayStory($story, $config);
            $html[] = self::getRandomAd($ads, $i);
        }

        $html[] = '</ul>';
        $html[] = self::displayPagination($pagination, $config);
        $html[] = '</div>';

        return implode("\n", $html);
    }

    public static function displayStoryVotes($story, $config)
    {
        if (empty($config['voting'])) {
            return '';
        }

        $html = [];
        $html[] = '<div class="story-votes">';
        $html[] = '<div class="badge badge-secondary story-votes-counter">' . $story->votes_total . '</div>';

        if (!empty($config['votingArrows'])) {
            if (is_null($story->vote_value)) {
                $html[] = '<a href="' . Route::_('index.php?option=com_rssfactory&task=story.vote&format=raw&story_id=' . $story->id . '&vote=1') . '" class="text-muted muted small story-vote-up"><i class="icon-arrow-up"></i></a>';
                $html[] = '<a href="' . Route::_('index.php?option=com_rssfactory&task=story.vote&format=raw&story_id=' . $story->id . '&vote=-1') . '" class="text-muted muted small story-vote-down"><i class="icon-arrow-down"></i></a>';
            } else {
                $html[] = '<span class="small story-vote-up ' . (1 == $story->vote_value ? '' : 'muted text-muted') . '"><i class="icon-arrow-up"></i></span>';
                $html[] = '<span class="small story-vote-down ' . (-1 == $story->vote_value ? '' : 'muted text-muted') . '"><i class="icon-arrow-down"></i></span>';
            }
        }

        $html[] = '</div>';
        return implode("\n", $html);
    }

    protected static function displayStory($story, $config)
    {
        $original = clone($story);
        $story = self::changeStoryEncoding($story, $config);
        $story = self::prepareItemForDisplay($story, $config);

        $html = [];
        $html[] = '<li id="story-' . $story->id . '" class="story story-' . $story->id . '">';
        $html[] = self::displayStoryVotes($story, $config);
        $html[] = '<div class="story-link">';
        $html[] = self::displayStoryTitle($story, $config);
        $html[] = self::displayChannelTitle($story, $config);
        $html[] = self::displayStoryDate($story, $config);
        $html[] = self::displayStoryComments($story, $config);
        $html[] = self::displayStoryDescription($story, $config, $original);
        $html[] = '</div>';
        $html[] = '</li>';

        return implode("\n", $html);
    }

    protected static function getConfig($config)
    {
        $configuration = ComponentHelper::getParams('com_rssfactory');
        $defaults = [
            'mode'          => $configuration->get('liststyle', 'tiled'),
            'columns'       => $configuration->get('liststylecolumns', 2),
            'tabs_position' => 'top',
            'bookmarks'     => true,
            'voting'        => true,
            'comments'      => true,
            'dateFormat'    => $configuration->get('date_format', 'l, d F Y'),
            'date'          => !$configuration->get('hideDate', 0),
            'votingArrows'  => true,
            'pagination'    => true,
            'description_display'        => $configuration->get('showfeeddescription', 'tooltip'),
            'description_strip_tags'     => $configuration->get('strip_html_tags', 1),
            'description_allow_tags'     => $configuration->get('allowed_html_tags', ''),
            'force_output_charset'       => $configuration->get('force_output_charset', ''),
            'route_links'                => $configuration->get('readmore_options', 0),
            'story_source_link_target'   => $configuration->get('story_source_link_target', 'new_window'),
            'story_source_link_behavior' => $configuration->get('story_source_link_behavior', 'link'),
            'use_favicons'               => $configuration->get('use_favicons', 1),
            'show_enclosures'            => $configuration->get('show_enclosures', 0),
            'show_empty_feeds'           => $configuration->get('showemptysources', 0),
            'story_title_trim'           => 0,
            'story_desc_trim'            => 0,
            'list_style_channel_title_display' => $configuration->get('list_style_channel_title_display', 1),
        ];

        $config = array_merge($defaults, $config);

        // Permissions (Joomla 4 ACL checks)
        $user = Factory::getApplication()->getIdentity();
        if ($config['bookmarks'] && !$user->authorise('frontend.favorites', 'com_rssfactory')) {
            $config['bookmarks'] = false;
        }
        if ($config['voting'] && !$user->authorise('frontend.voting', 'com_rssfactory')) {
            $config['voting'] = false;
        }
        if ($config['comments'] && !$user->authorise('frontend.comment.view', 'com_rssfactory')) {
            $config['comments'] = false;
        }

        if (is_array($config['columns'])) {
            $config['columns'] = $config['columns'][0];
        }

        return $config;
    }

    protected static function displayTiled($feeds, $config, $ads = null)
    {
        $columns = 'display-columns-' . $config['columns'];
        $html = [];
        $i = 0;

        $html[] = '<div class="row-fluid ' . $columns . ' row">';
        foreach ($feeds as $feed) {
            if (!$config['show_empty_feeds'] && empty($feed->stories)) {
                continue;
            }
            if ($i && 0 == $i % $config['columns']) {
                $html[] = '</div>';
                $html[] = '<div class="row-fluid ' . $columns . ' row">';
            }
            $html[] = '<div class="span' . (12 / $config['columns']) . ' col-' . (12 / $config['columns']) . '">';
            $html[] = self::displayFeed($feed, $config, $ads);
            $html[] = '</div>';
            $i++;
        }
        $html[] = '</div>';
        return implode("\n", $html);
    }

    protected static function displayTabbed($feeds, $config, $ads = null)
    {
        $html = [];
        $id = uniqid();
        $selector = 'feeds-' . $id;

        $html[] = HTMLHelper::_('bootstrap.startTabSet', $selector, ['active' => 'story-0']);
        foreach ($feeds as $i => $feed) {
            $html[] = HTMLHelper::_('bootstrap.addTab', $selector, 'story-' . $i, $feed->title);
            $html[] = self::displayFeed($feed, $config, $ads);
            $html[] = HTMLHelper::_('bootstrap.endTab');
        }
        $html[] = HTMLHelper::_('bootstrap.endTabSet');
        return implode("\n", $html);
    }

    protected static function displaySliders($feeds, $config, $ads = null)
    {
        $html = [];
        $id = uniqid();
        $selector = 'feeds-slider-' . $id;

        $html[] = HTMLHelper::_('bootstrap.startAccordion', $selector, ['active' => 'feed-slider-0-' . $id]);
        foreach ($feeds as $i => $feed) {
            $html[] = HTMLHelper::_('bootstrap.addSlide', $selector, $feed->title, 'feed-slider-' . $i . '-' . $id);
            $html[] = self::displayFeed($feed, $config, $ads);
            $html[] = HTMLHelper::_('bootstrap.endSlide');
        }
        $html[] = HTMLHelper::_('bootstrap.endAccordion');
        return implode("\n", $html);
    }

    protected static function displayList($feeds, $config, $ads = null)
    {
        self::loadAssets();

        $html = [];
        $html[] = '<div class="feed">';
        $html[] = '<div class="feed-stories">';
        $html[] = '<hr />';
        $html[] = '<ul class="stories ' . ($config['voting'] ? 'voting' : '') . '">';
        foreach ($feeds['stories'] as $i => $feed) {
            $html[] = self::displayStory($feed, $config);
            $html[] = self::getRandomAd($ads, $i);
        }
        $html[] = '</ul>';
        $html[] = self::displayPagination($feeds['pagination'], $config);
        $html[] = '</div>';
        $html[] = '</div>';
        return implode("\n", $html);
    }

    protected static function displayFeed($feed, $config, $ads = null)
    {
        if (!$config['show_empty_feeds'] && empty($feed->stories)) {
            return '';
        }

        $html = [];
        $html[] = '<a name="feed-' . $feed->id . '"></a>';
        $html[] = '<div class="feed feed-' . $feed->id . '">';
        $html[] = '<div class="lead">';
        $html[] = self::displayFeedActions($feed, $config, $config['bookmarks']);
        $html[] = $feed->title;

        if ($config['bookmarks']) {
            $html[] = '<i class="icon-bookmark feed-title-bookmarked" ' . (empty($feed->is_favorite) ? 'style="display: none;"' : '') . '></i>';
        }

        $html[] = '</div>';
        $html[] = '<hr />';
        $html[] = self::displayStories($feed->stories, $feed->pagination, $config, $ads);
        $html[] = '</div>';

        return implode("\n", $html);
    }

    protected static function displayFeedActions($feed, $config, $bookmarks)
    {
        $layout = new FileLayout('feed.actions', JPATH_SITE . '/components/com_rssfactory/layouts');
        return $layout->render([
            'bookmarks' => $bookmarks,
            'feed'      => $feed,
            'config'    => $config,
        ]);
    }

    protected static function loadAssets()
    {
        if (!self::$assetsLoaded) {
            HTMLHelper::_('jquery.framework');
            HTMLHelper::_('stylesheet', 'com_rssfactory/feeds.css', ['version' => 'auto', 'relative' => true]);
            HTMLHelper::_('script', 'com_rssfactory/feeds.js', ['version' => 'auto', 'relative' => true]);
            HTMLHelper::_('script', 'com_rssfactory/growl.js', ['version' => 'auto', 'relative' => true]);
            self::$assetsLoaded = true;
        }
        return true;
    }

    protected static function displayPagination($pagination, $config)
    {
        if (empty($config['pagination']) || !$pagination instanceof Pagination) {
            return '';
        }

        $html = [];
        $html[] = '<div class="pagination pagination-small pagination-sm">';
        $html[] = $pagination->getPagesLinks();
        $html[] = '</div>';
        $html[] = '<div class="progress progress-striped active" style="display: none;">';
        $html[] = '<div class="bar" style="width: 100%;"></div>';
        $html[] = '</div>';

        return implode("\n", $html);
    }

    protected static function changeStoryEncoding($story, $config)
    {
        if ('' == $config['force_output_charset']) {
            return $story;
        }

        $array = ['channel_link', 'item_title', 'item_description'];
        foreach ($array as $item) {
            $story->$item = self::changeEncoding($story->$item, $story->encoding, $config['force_output_charset']);
        }
        return $story;
    }

    protected static function changeEncoding($data, $input, $output)
    {
        $input = self::getEncoding($input);
        $output = self::getEncoding($output);

        if ($input == $output || $input == '' || $output == '') {
            return $data;
        }

        if (function_exists('iconv') && ($return = @iconv($input, "$output//IGNORE", $data))) {
            return $return;
        } elseif (function_exists('iconv') && ($return = @iconv($input, $output, $data))) {
            return $return;
        } elseif (function_exists('mb_convert_encoding') && ($return = @mb_convert_encoding($data, $output, $input))) {
            return $return;
        } elseif ($input == 'ISO-8859-1' && $output == 'UTF-8') {
            return utf8_encode($data);
        } elseif ($input == 'UTF-8' && $output == 'ISO-8859-1') {
            return utf8_decode($data);
        }

        return $data;
    }

    protected static function getEncoding($encoding)
    {
        if (!$encoding) {
            return 'UTF-8';
        }
        $encoding = strtoupper(trim($encoding));
        switch ($encoding) {
            case 'UTF8':
            case 'UTF-8':
                return 'UTF-8';
            case 'ISO8859-1':
            case 'ISO-8859-1':
            case 'ISO_8859-1':
            case 'LATIN1':
            case 'LATIN-1':
                return 'ISO-8859-1';
            case 'ISO8859-15':
            case 'ISO-8859-15':
            case 'ISO_8859-15':
            case 'LATIN9':
            case 'LATIN-9':
                return 'ISO-8859-15';
            case 'WINDOWS-1251':
            case 'CP1251':
                return 'WINDOWS-1251';
            case 'WINDOWS-1252':
            case 'CP1252':
                return 'WINDOWS-1252';
            case 'ASCII':
                return 'ASCII';
            default:
                return $encoding;
        }
    }

    protected static function getStoryAnchorTarget($config)
    {
        if ('new_window' == $config['story_source_link_target']) {
            return 'target="_blank"';
        }
        return '';
    }

    protected static function getStoryAnchorModal($config)
    {
        if ('modal' == $config['story_source_link_behavior']) {
            HTMLHelper::_('behavior.modal', 'a.modal-mootools');
            return 'rel="{ handler: \'iframe\'}"';
        }
        return false;
    }

    public static function getEnclosuresFromStory($story)
    {
        $enclosures = @unserialize(base64_decode($story->item_enclosure));
        $html = [];

        if ($enclosures) {
            $html[] = '<div class="enclosures">';
            $html[] = '<strong>' . Text::_('COM_RSSFACTORY_FEED_MEDIA_FILES') . '</strong>';
            $html[] = '<ol>';
            foreach ($enclosures as $enclosure) {
                $attributes = [];
                if (isset($enclosure['link'])) {
                    $explode = explode('/', $enclosure['link']);
                    $filename = end($explode);
                } else {
                    $filename = 'File';
                }
                $filename = substr($filename, 0, strpos($filename, '?') ?: strlen($filename));
                if (isset($enclosure['type'])) {
                    $attributes['type'] = $enclosure['type'];
                }
                if (isset($enclosure['length'])) {
                    $attributes['length'] = (round($enclosure['length'] / 1024, 2) . 'KB');
                }
                $html[] = '<li>';
                $html[] = '<a target="_blank" rel="nofollow" href="' . $enclosure['link'] . '">' . $filename . '</a>';
                if ($attributes) {
                    $html[] = '(' . implode(', ', $attributes) . ')';
                }
                $html[] = '</li>';
            }
            $html[] = '</ol>';
            $html[] = '</div>';
        }
        return implode("\n", $html);
    }

    protected static function prepareItemForDisplay($story, $config)
    {
        $story->item_link = self::prepareItemLink($story->id, $story->item_link, $config['route_links']);
        $story->item_title = self::prepareItemTitle($story->item_title, $config['story_title_trim']);
        $story->item_description = self::prepareItemDescription($story->item_description, $config);
        return $story;
    }

    protected static function prepareItemLink($storyId, $storyLink, $routedLinks)
    {
        if (!$routedLinks) {
            return $storyLink;
        }
        return Route::_('index.php?option=com_rssfactory&task=story.route&story_id=' . $storyId);
    }

    protected static function prepareItemTitle($storyTitle, $trim)
    {
        if ($trim > 0) {
            return HTMLHelper::_('string.truncate', $storyTitle, $trim);
        }
        return $storyTitle;
    }

    protected static function prepareItemDescription($description, $config)
    {
        static $allowedTags = null;

        if ($config['description_strip_tags']) {
            if (is_null($allowedTags)) {
                $allowedTags = trim($config['description_allow_tags']);
                if ('' != $allowedTags) {
                    $allowedTags = '<' . implode('><', explode(',', $allowedTags)) . '>';
                }
            }
            $description = strip_tags($description, $allowedTags);
        }

        if ($config['story_desc_trim']) {
            $description = HTMLHelper::_('string.truncate', $description, $config['story_desc_trim']);
        }

        return $description;
    }

    protected static function displayStoryTitle($story, $config)
    {
        $html = [];
        switch ($config['description_display']) {
            case 'tooltip':
                HTMLHelper::_('behavior.tooltip');
                $tooltip = htmlspecialchars($story->item_description, ENT_COMPAT, 'UTF-8');
                $target = self::getStoryAnchorTarget($config);
                $modal = self::getStoryAnchorModal($config);
                $html[] = '<span class="hasTooltip" title="' . $tooltip . '">';
                $html[] = '<a href="' . $story->item_link . '" class="' . ($modal ? 'modal-mootools' : '') . '" ' . $target . ' ' . $modal . '>';
                $html[] = $story->item_title;
                $html[] = '</a></span>';
                break;
            case 'table':
                $html[] = '<a href="#" class="feed-table">' . $story->item_title . '</a>';
                break;
            case 'modal':
                $html[] = '<a href="#" class="feed-modal">' . $story->item_title . '</a>';
                break;
            case 'none':
                $html[] = '<a href="' . $story->item_link . '">' . $story->item_title . '</a>';
                break;
        }
        return implode("\n", $html);
    }

    protected static function displayStoryDate($story, $config)
    {
        if (empty($config['date'])) {
            return '';
        }
        return '<div class="muted small text-muted"><i class="icon-calendar"></i>' . HTMLHelper::_('date', $story->item_date, $config['dateFormat']) . '</div>';
    }

    protected static function displayStoryComments($story, $config)
    {
        if (empty($config['comments'])) {
            return '';
        }
        $html = [];
        $html[] = '<div class="small muted text-muted">';
        $html[] = '<a href="' . Route::_('index.php?option=com_rssfactory&view=comments&story_id=' . $story->id) . '" class="small muted text-muted">';
        $html[] = '<i class="icon-comments"></i>' . Text::plural('COM_RSSFACTORY_FEEDS_FEED_COMMENTS', $story->comments_total);
        $html[] = '</a>';
        $html[] = '</div>';
        return implode("\n", $html);
    }

    protected static function displayStoryDescription($story, $config, $original)
    {
        $html = [];
        switch ($config['description_display']) {
            case 'table':
                $target = self::getStoryAnchorTarget($config);
                $modal = self::getStoryAnchorModal($config);
                $html[] = '<div style="display: none;" class="well card"><div class="card-body">';
                $html[] = $story->item_description;
                if ($config['show_enclosures']) {
                    $html[] = self::getEnclosuresFromStory($story);
                }
                $html[] = '<div>';
                $html[] = '<a href="' . $story->item_link . '" class="btn btn-small btn-sm btn-secondary' . ($modal ? ' modal-mootools' : '') . '" ' . $target . ' ' . $modal . '>';
                $html[] = Text::_('COM_RSSFACTORY_FEED_STORY_DISPLAY_READ_MORE');
                $html[] = '</a>';
                $html[] = '</div>';
                $html[] = '</div></div>';
                break;
            case 'modal':
                $target = self::getStoryAnchorTarget($config);
                $modal = self::getStoryAnchorModal($config);
                $version = (int)Version::MAJOR_VERSION;
                $layout = new FileLayout('story.modal' . $version, JPATH_SITE . '/components/com_rssfactory/layouts');
                $html[] = $layout->render([
                    'target'   => $target,
                    'modal'    => $modal,
                    'original' => $original,
                    'config'   => $config,
                    'story'    => $story,
                ]);
                break;
        }
        return implode("\n", $html);
    }

    protected static function displayChannelTitle($story, $config)
    {
        if ('list' !== $config['mode']) {
            return '';
        }
        if (empty($config['list_style_channel_title_display'])) {
            return '';
        }
        return '<div class="muted small text-muted"><i class="icon-feed"></i>' . $story->channel_title . '</div>';
    }

    protected static function getRandomAd(&$ads, $counter)
    {
        $html = [];
        $configuration = ComponentHelper::getParams('com_rssfactory');
        if ($ads && $counter && ($counter + 1) % $configuration->get('ads_rows_repeat', 3) == 0) {
            $key = array_rand($ads, 1);
            $ad = $ads[$key];
            unset($ads[$key]);
            $html[] = '<div class="rssfactory-ad">';
            $html[] = $ad->adtext;
            $html[] = '</div>';
        }
        return implode("\n", $html);
    }
}
