<?php
/**
 * @copilot migrate this file from Joomla 3 to Joomla 4 syntax
 * Retain full business logic, refactor deprecated APIs, apply DI pattern
 */
namespace Joomla\Component\Rssfactory\Administrator\Helper\Rules;

use Joomla\CMS\Filesystem\Folder;

defined('_JEXEC') or die;

class HtmlRule
{
    protected static $rules = null;

    public static function options()
    {
        $options = array();

        foreach (self::getRules() as $rule) {
            $options[$rule->getType()] = $rule->getLabel();
        }

        return $options;
    }

    public static function templates()
    {
        $templates = array();

        foreach (self::getRules() as $rule) {
            $templates[] = 'data-template-' . $rule->getType() . '="' . htmlentities($rule->getTemplate()) . '"';
        }

        return implode(' ', $templates);
    }

    protected static function getRules()
    {
        if (is_null(self::$rules)) {
            self::$rules = array();

            $path = JPATH_COMPONENT_ADMINISTRATOR . '/helpers/rules';
            $folders = Folder::folders($path);

            foreach ($folders as $folder) {
                self::$rules[$folder] = \RssFactoryRule::getInstance($folder);
            }
        }

        return self::$rules;
    }
}
