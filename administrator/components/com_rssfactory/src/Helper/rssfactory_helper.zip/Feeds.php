<?php
/**
 * @package     Joomla.Administrator
 * @subpackage  com_rssfactory
 * @author      thePHPfactory
 * @copyright   Copyright (C) 2011 SKEPSIS Consult SRL. All Rights Reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

// @copilot migrate this file from Joomla 3 to Joomla 4 syntax
// Retain full business logic, refactor deprecated APIs, apply DI pattern

namespace Joomla\Component\Rssfactory\Administrator\Helper;

defined('_JEXEC') or die;

use Joomla\CMS\Filesystem\File;
use Joomla\CMS\Uri\Uri;
use Joomla\CMS\HTML\HTMLHelper;

/**
 * RSS Factory Feeds Helper
 */
class FeedsHelper
{
    /**
     * Get the feed icon URL or HTML <img> tag.
     *
     * @param int $feedId
     * @param string|false $url
     * @param array $attributes
     * @return string
     */
    public static function icon($feedId, $url = false, array $attributes = [])
    {
        $filename = 'default.png';
        $path = JPATH_SITE . '/media/com_rssfactory/icos/ico_' . md5($feedId) . '.png';

        if (File::exists($path)) {
            $filename = 'ico_' . md5($feedId) . '.png';
        }

        $src = Uri::root() . 'media/com_rssfactory/icos/' . $filename;

        if ($url) {
            return $src;
        }

        return HTMLHelper::_('image', $src, 'ico' . $feedId, $attributes);
    }

    /**
     * Get the feed title (with fallback).
     *
     * @param object $feed
     * @return string
     */
    public static function getTitle($feed)
    {
        return !empty($feed->title) ? $feed->title : 'Untitled Feed';
    }

    /**
     * Get the feed status label.
     *
     * @param object $feed
     * @return string
     */
    public static function getStatus($feed)
    {
        return $feed->published ? 'Published' : 'Unpublished';
    }

    // Add more helper methods as needed for RSS Factory feeds business logic.
}
