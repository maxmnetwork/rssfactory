<?php
namespace Joomla\Component\Rssfactory\Administrator\Helper;

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Application\CMSApplication;
use Joomla\Database\DatabaseDriver;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Log\Log;
use Joomla\CMS\Component\ComponentHelper;

class FactoryHelper
{
    /**
     * @var CMSApplication
     */
    protected $app;

    /**
     * @var DatabaseDriver
     */
    protected $db;

    /**
     * Constructor with DI.
     *
     * @param CMSApplication|null $app
     * @param DatabaseDriver|null $db
     */
    public function __construct(CMSApplication $app = null, DatabaseDriver $db = null)
    {
        $this->app = $app ?: Factory::getApplication();
        $this->db  = $db ?: Factory::getDbo();
    }

    /**
     * Example: Get a component parameter
     *
     * @param string $param
     * @param mixed $default
     * @return mixed
     */
    public function getParam(string $param, $default = null)
    {
        $params = ComponentHelper::getParams('com_rssfactory');
        return $params->get($param, $default);
    }

    /**
     * Example: Log a message
     *
     * @param string $message
     * @param string $level
     */
    public function log($message, $level = 'info')
    {
        Log::add($message, Log::INFO, 'com_rssfactory');
    }

    /**
     * Example: Get a translated string
     *
     * @param string $key
     * @return string
     */
    public function t($key)
    {
        return Text::_($key);
    }

    // Add your migrated business logic methods below
}