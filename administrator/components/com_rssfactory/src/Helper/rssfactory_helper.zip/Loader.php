<?php
/**
-------------------------------------------------------------------------
rssfactory - Rss Factory 4.3.6
-------------------------------------------------------------------------
 * @author thePHPfactory
 * @copyright Copyright (C) 2011 SKEPSIS Consult SRL. All Rights Reserved.
 * @license - http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * Websites: http://www.thePHPfactory.com
 * Technical Support: Forum - http://www.thePHPfactory.com/forum/
-------------------------------------------------------------------------
*/
// @copilot migrate this file from Joomla 3 to Joomla 4 syntax
// Retain full business logic, refactor deprecated APIs, apply DI pattern

namespace Joomla\Component\Rssfactory\Administrator\Helper;

defined('_JEXEC') or die;

use Joomla\CMS\Uri\Uri;

// Define constants only once.
if (!defined('RSS_FACTORY_COMPONENT_NAME')) {
    define('RSS_FACTORY_COMPONENT_NAME', 'rssfactory');
    define('RSS_FACTORY_COMPONENT_PATH', JPATH_ROOT . '/components/com_' . RSS_FACTORY_COMPONENT_NAME);
    define('RSS_FACTORY_COMPONENT_ADMIN_PATH', JPATH_ROOT . '/administrator/components/com_' . RSS_FACTORY_COMPONENT_NAME);
    define('RSS_FACTORY_COMPONENT_URI', Uri::root() . 'components/com_' . RSS_FACTORY_COMPONENT_NAME . '/');
    define('RSS_FACTORY_COMPONENT_ADMIN_URI', Uri::root() . 'administrator/components/com_' . RSS_FACTORY_COMPONENT_NAME . '/');
    define('RSS_FACTORY_XAJAX_PATH', RSS_FACTORY_COMPONENT_PATH . '/xajax');
    define('RSS_FACTORY_CLASSNAME', 'RFPROController');
    define('RSS_FACTORY_ADMIN_CLASSNAME', 'RFPROAdminController');
    define('RSS_FACTORY_TMP_PATH', JPATH_ROOT . '/administrator/components/com_' . RSS_FACTORY_COMPONENT_NAME . '/tmp');
    define('RSS_FACTORY_LAYOUTS_PATH', RSS_FACTORY_COMPONENT_PATH . '/layouts');
    define('RSS_FACTORY_SITE_SAFE_MODE_ON', false);
}
define('RSS_FACTORY_XAJAX_PATH', RSS_FACTORY_COMPONENT_PATH . '/xajax');
define('RSS_FACTORY_CLASSNAME', 'RFPROController');
define('RSS_FACTORY_ADMIN_CLASSNAME', 'RFPROAdminController');
define('RSS_FACTORY_TMP_PATH', JPATH_ROOT . '/administrator/components/com_' . RSS_FACTORY_COMPONENT_NAME . '/tmp');
define('RSS_FACTORY_LAYOUTS_PATH', RSS_FACTORY_COMPONENT_PATH . '/layouts');
define('RSS_FACTORY_SITE_SAFE_MODE_ON', false);
define('RSS_FACTORY_LAYOUTS_PATH', RSS_FACTORY_COMPONENT_PATH . '/layouts');
define('RSS_FACTORY_SITE_SAFE_MODE_ON', false);
define('RSS_FACTORY_LAYOUTS_PATH', RSS_FACTORY_COMPONENT_PATH . '/layouts');
define('RSS_FACTORY_SITE_SAFE_MODE_ON', false);
