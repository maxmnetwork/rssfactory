<?php
/**
-------------------------------------------------------------------------
rssfactory - Rss Factory 4.3.6
-------------------------------------------------------------------------
 * @author thePHPfactory
 * @copyright Copyright (C) 2011 SKEPSIS Consult SRL. All Rights Reserved.
 * @license - http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * Websites: http://www.thePHPfactory.com
 * Technical Support: Forum - http://www.thePHPfactory.com/forum/
-------------------------------------------------------------------------
*/
// @copilot migrate this file from Joomla 3 to Joomla 4 syntax
// Retain full business logic, refactor deprecated APIs, apply DI pattern

namespace Joomla\Component\Rssfactory\Administrator\Helper\Factory;

defined('_JEXEC') or die;

use Joomla\CMS\HTML\HTMLHelper;

class FactoryHtmlRss
{
    protected static $option = 'com_rssfactory';

    public static function script($file, $framework = false, $relative = false, $path_only = false, $detect_browser = true, $detect_debug = true)
    {
        $file = self::parsePath($file);
        HTMLHelper::script($file, $framework, $relative, $path_only, $detect_browser, $detect_debug);
    }

    public static function stylesheet($file, $attribs = array(), $relative = false, $path_only = false, $detect_browser = true, $detect_debug = true)
    {
        $file = self::parsePath($file, 'css');
        HTMLHelper::stylesheet($file, $attribs, $relative, $path_only, $detect_browser, $detect_debug);
    }

    public static function registerHtml($html)
    {
        // Joomla 4: No need to register classes, use PSR-4 autoloading and namespaces.
        // This method is now a no-op for compatibility.
        return true;
    }

    protected static function parsePath($file, $type = 'js')
    {
        $path = array();
        $parts = explode('/', $file);

        $path[] = 'media';
        $path[] = self::$option;
        $path[] = 'assets';

        if ('admin' == $parts[0]) {
            $path[] = 'backend';
            unset($parts[0]);
            $parts = array_values($parts);
        } else {
            $path[] = 'frontend';
        }

        $path[] = $type;

        $count = count($parts);
        foreach ($parts as $i => $part) {
            if ($i + 1 == $count) {
                $path[] = $part . '.' . $type;
            } else {
                $path[] = $part;
            }
        }

        return implode('/', $path);
    }
}
