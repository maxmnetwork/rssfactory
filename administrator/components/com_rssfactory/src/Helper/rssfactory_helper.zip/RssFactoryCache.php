<?php
// @copilot migrate this file from Joomla 3 to Joomla 4 syntax
// Retain full business logic, refactor deprecated APIs, apply DI pattern

namespace Joomla\Component\Rssfactory\Administrator\Helper;

defined('_JEXEC') or die;

use Joomla\CMS\Factory;

class RssFactoryCache
{
    protected static $instance;
    protected $cache = [];

    public static function getInstance()
    {
        if (!self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function get($key)
    {
        if (isset($this->cache[$key])) {
            return $this->cache[$key];
        }

        $session = Factory::getApplication()->getSession();
        $value = $session->get($key, false, 'com_rssfactory');
        $this->cache[$key] = $value;
        return $value;
    }

    public function store($value, $key)
    {
        $session = Factory::getApplication()->getSession();
        $session->set($key, $value, 'com_rssfactory');
        $this->cache[$key] = $value;
        return true;
    }
}
